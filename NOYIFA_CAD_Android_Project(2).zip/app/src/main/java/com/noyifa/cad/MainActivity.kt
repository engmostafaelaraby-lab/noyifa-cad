package com.noyifa.cad

import android.annotation.SuppressLint
import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.UUID

class MainActivity : Activity() {
    private val serviceUuid = UUID.fromString("0000FFF0-0000-1000-8000-00805F9B34FB")
    private val characteristicUuid = UUID.fromString("0000FFF7-0000-1000-8000-00805F9B34FB")
    private lateinit var status: TextView
    private lateinit var distance: TextView
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        val title = TextView(this).apply { text = "NOYIFA Architectural CAD"; textSize = 24f; gravity = Gravity.CENTER }
        status = TextView(this).apply { text = "اضغط اتصال للبحث عن متر NOYIFA"; textSize = 16f; gravity = Gravity.CENTER }
        distance = TextView(this).apply { text = "--- m"; textSize = 42f; gravity = Gravity.CENTER }
        val connect = Button(this).apply { text = "اتصال بالمتر"; setOnClickListener { requestAndScan() } }
        layout.addView(title); layout.addView(status); layout.addView(distance); layout.addView(connect)
        setContentView(layout)
    }

    private fun requestAndScan() {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 7); return }
        startScan()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 7 && results.all { it == PackageManager.PERMISSION_GRANTED }) startScan()
        else status.text = "يجب السماح بصلاحيات Bluetooth"
    }

    @Suppress("MissingPermission")
    private fun startScan() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = manager.adapter
        if (adapter == null || !adapter.isEnabled) { status.text = "شغّل Bluetooth أولاً"; return }
        scanner = adapter.bluetoothLeScanner
        status.text = "جارٍ البحث عن جهاز NOYIFA..."
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(serviceUuid)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner?.startScan(listOf(filter), settings, scanCallback)
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            scanner?.stopScan(this)
            runOnUiThread { status.text = "تم العثور على ${result.device.name ?: "NOYIFA"}، جارٍ الاتصال..." }
            gatt = result.device.connectGatt(this@MainActivity, false, gattCallback)
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { status.text = "فشل البحث: $errorCode" }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            else runOnUiThread { status.text = "انقطع الاتصال" }
        }
        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val c = g.getService(serviceUuid)?.getCharacteristic(characteristicUuid)
            if (c == null) { runOnUiThread { status.text = "لم يتم العثور على FFF7" }; return }
            g.setCharacteristicNotification(c, true)
            val descriptor = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805F9B34FB"))
            if (descriptor != null) {
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                else {
                    @Suppress("DEPRECATION")
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    @Suppress("DEPRECATION")
                    g.writeDescriptor(descriptor)
                }
            }
            runOnUiThread { status.text = "متصل بالمتر — استقبل القياسات" }
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            showMeasurement(value)
        }
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            c.value?.let { showMeasurement(it) }
        }
    }

    private fun showMeasurement(data: ByteArray) {
        if (data.size != 13) return
        val mm = ((data[7].toInt() and 0xFF) shl 8) or (data[8].toInt() and 0xFF)
        if (mm <= 0) return
        runOnUiThread { distance.text = "%.3f m".format(mm / 1000.0) }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) {
            try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        }
        gatt?.close()
    }
}
